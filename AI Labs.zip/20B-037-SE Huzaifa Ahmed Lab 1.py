import os
from time import sleep

def CheckPalindrome(testStr, f, l):
    if f == l:
        return True
    if testStr[f] != testStr[l]:
        return False
    if f < l + 1:
        return CheckPalindrome(testStr, f + 1, l - 1)
    return True


def PalCheck(palString):
    n = len(palString) - 1
    if CheckPalindrome(palString, 0, n):
        print(f"{palString} is palindrome")
        return
    print(f"{palString} is not palindrome")


PalCheck("wow")


def ReverseString(iString):
    if len(iString) == 0:
        return iString 
    else:
        return ReverseString(iString[1:]) + iString[0]
    

print(ReverseString("Hello"))

def SumArray(iArr):
    if len(iArr) == 1:
        return iArr[0]
    else:
        return SumArray(iArr[1:]) + iArr[0]

print(SumArray([1, 2, 3]))


def PF():
    joined = False
    while True:
        os.system("cls")
        print("Welcome to CSGO")
        if joined:
            print("Joined team")
        print("select an option to continue")
        if joined:
            print("1. Leave team")
        else:
            print("1. Join the boys")
        print("2. Start competitive")
        print("3. Quit Game")
        
        while True:
            try:
                userInp = int(input())
                break
            except:
                print("Invalid Input! Try again")

        if userInp == 3:
            os.system("cls")
            print("Goodbye!")
            sleep(2)
            break
        elif userInp == 1:
            joined = not joined
        elif userInp == 2:
            os.system("cls")
            print("Started match!")
            sleep(1)
            print("You won!")
            sleep(2)


# Comment this to see recursion output
PF()
