import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder
from sklearn.naive_bayes import GaussianNB
from sklearn.svm import SVC
from sklearn.model_selection import cross_val_score, train_test_split
from sklearn.metrics import f1_score, accuracy_score

# Step 1: Load the dataset
df = pd.read_csv('StudentData.csv')

# Preprocessing: Encode Text Data
df = df.apply(LabelEncoder().fit_transform)

# Step 2: Split the dataset into features (X) and target variable (y)
x = df.iloc[:, :-1].values
y = df.iloc[:, -1].values

# Step 3: Split the dataset into train and test sets (70% train, 30% test)
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.3, random_state=42, stratify=y)

# Step 4: Train and evaluate Naive Bayes
naive_bayes = GaussianNB()
naive_bayes.fit(x_train, y_train)
naive_bayes_pred = naive_bayes.predict(x_test)

naive_bayes_f1 = f1_score(y_test, naive_bayes_pred, average='macro')
naive_bayes_accuracy = accuracy_score(y_test, naive_bayes_pred)

print("Naive Bayes Performance:")
print("F-measure:", naive_bayes_f1)
print("Accuracy:", naive_bayes_accuracy)
print()

# Step 5: Train and evaluate SVM
svm = SVC()
svm.fit(x_train, y_train)
svm_pred = svm.predict(x_test)

svm_f1 = f1_score(y_test, svm_pred, average='macro')
svm_accuracy = accuracy_score(y_test, svm_pred)

print("SVM Performance:")
print("F-measure:", svm_f1)
print("Accuracy:", svm_accuracy)
print()

# Step 6: Perform 10-fold cross-validation on Naive Bayes and SVM (stratified)
nb_scores = cross_val_score(naive_bayes, x, y, cv=10)
svm_scores = cross_val_score(svm, x, y, cv=10)

print("Naive Bayes Cross-validation Scores:")
print(nb_scores)
print("Mean Accuracy:", np.mean(nb_scores))
print()

print("SVM Cross-validation Scores:")
print(svm_scores)
print("Mean Accuracy:", np.mean(svm_scores))
