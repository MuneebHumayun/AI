import pandas as pd
import numpy as np
from sklearn.naive_bayes import GaussianNB
from sklearn.svm import SVC
from sklearn.model_selection import cross_val_score, train_test_split
from sklearn.metrics import f1_score, accuracy_score
from sklearn.impute import SimpleImputer

# Step 1: Load the Dermatology dataset
df = pd.read_csv('dermatology.data', header=None)

# Step 2: Replace missing values ('?') with NaN
df.replace('?', np.nan, inplace=True)

# Step 3: Split the dataset into features (X) and target variable (y)
X = df.iloc[:, :-1].values
y = df.iloc[:, -1].values

# Step 4: Impute missing values with the mean of the respective column
imputer = SimpleImputer(strategy='mean')
X = imputer.fit_transform(X)

# Step 5: Split the dataset into train and test sets (70% train, 30% test)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# Step 6: Train and evaluate Naive Bayes
naive_bayes = GaussianNB()
naive_bayes.fit(X_train, y_train)
naive_bayes_pred = naive_bayes.predict(X_test)

naive_bayes_f1 = f1_score(y_test, naive_bayes_pred, average='macro')
naive_bayes_accuracy = accuracy_score(y_test, naive_bayes_pred)

print("Naive Bayes Performance:")
print("F-measure:", naive_bayes_f1)
print("Accuracy:", naive_bayes_accuracy)
print()

# Step 7: Train and evaluate SVM
svm = SVC()
svm.fit(X_train, y_train)
svm_pred = svm.predict(X_test)

svm_f1 = f1_score(y_test, svm_pred, average='macro')
svm_accuracy = accuracy_score(y_test, svm_pred)

print("SVM Performance:")
print("F-measure:", svm_f1)
print("Accuracy:", svm_accuracy)
print()

# Step 8: Perform 10-fold cross-validation on Naive Bayes and SVM
nb_scores = cross_val_score(naive_bayes, X, y, cv=10)
svm_scores = cross_val_score(svm, X, y, cv=10)

print("Naive Bayes Cross-validation Scores:")
print(nb_scores)
print("Mean Accuracy:", np.mean(nb_scores))
print()

print("SVM Cross-validation Scores:")
print(svm_scores)
print("Mean Accuracy:", np.mean(svm_scores))
