import numpy as np
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.naive_bayes import GaussianNB
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, f1_score

# Load the dataset (replace with your own dataset)
data = load_iris()
X = data.data
y = data.target

# Split the dataset into train and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# Apply Naïve Bayes classifier
nb_classifier = GaussianNB()
nb_classifier.fit(X_train, y_train)
nb_predictions = nb_classifier.predict(X_test)

# Calculate F-measure and Accuracy for Naïve Bayes
nb_fmeasure = f1_score(y_test, nb_predictions, average='weighted')
nb_accuracy = accuracy_score(y_test, nb_predictions)

# Apply SVM classifier
svm_classifier = SVC()
svm_classifier.fit(X_train, y_train)
svm_predictions = svm_classifier.predict(X_test)

# Calculate F-measure and Accuracy for SVM
svm_fmeasure = f1_score(y_test, svm_predictions, average='weighted')
svm_accuracy = accuracy_score(y_test, svm_predictions)

# Perform 10-fold cross-validation
nb_scores = cross_val_score(nb_classifier, X, y, cv=10)
svm_scores = cross_val_score(svm_classifier, X, y, cv=10)

# Calculate average F-measure and Accuracy across the 10-fold cross-validation
nb_avg_fmeasure = np.mean(nb_scores)
nb_avg_accuracy = np.mean(nb_scores)
svm_avg_fmeasure = np.mean(svm_scores)
svm_avg_accuracy = np.mean(svm_scores)

# Print the results
print("Naïve Bayes Performance:")
print("F-measure: {:.4f}".format(nb_fmeasure))
print("Accuracy: {:.4f}".format(nb_accuracy))
print("Average F-measure (10-fold CV): {:.4f}".format(nb_avg_fmeasure))
print("Average Accuracy (10-fold CV): {:.4f}".format(nb_avg_accuracy))

print("\nSVM Performance:")
print("F-measure: {:.4f}".format(svm_fmeasure))
print("Accuracy: {:.4f}".format(svm_accuracy))
print("Average F-measure (10-fold CV): {:.4f}".format(svm_avg_fmeasure))
print("Average Accuracy (10-fold CV): {:.4f}".format(svm_avg_accuracy))