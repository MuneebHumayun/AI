import pandas as pd
import numpy as np
from sklearn.naive_bayes import GaussianNB
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.metrics import confusion_matrix
from sklearn.impute import SimpleImputer

df = pd.read_csv('dermatology.data', header=None)

df = df.replace('?', np.nan)  
X = df.iloc[:, :-1].values  
y = df.iloc[:, -1].values   

imputer = SimpleImputer(strategy='mean')
X = imputer.fit_transform(X)

classifier = GaussianNB()

splits = [(0.6, 0.4), (0.7, 0.3), (0.8, 0.2)]

for split in splits:
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=split[1], random_state=42)
    classifier.fit(X_train, y_train)
    y_pred = classifier.predict(X_test)
    confusion_mat = confusion_matrix(y_test, y_pred)
    
    print("Train/Test Split: {:.0%}/{:.0%}".format(split[0], split[1]))
    print("Confusion Matrix:")
    print(confusion_mat)
    print()

k = 5
scores = cross_val_score(classifier, X, y, cv=k)

print("Cross-validation Scores:")
print(scores)
print("Mean Accuracy: {:.2f}".format(scores.mean()))
print("Standard Deviation: {:.2f}".format(scores.std()))
