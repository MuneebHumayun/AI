import pandas as pd
from sklearn.preprocessing import LabelEncoder

ds = pd.read_excel("weatherTemp.xlsx ")

x = ds.iloc[:,0:2].values #for input values
y = ds.iloc[:,2].values #for output value

# Import LabelEncoder
le = LabelEncoder()

# Converting string labels into numbers .
x [:, 0] = le.fit_transform (x[:, 0])
x [:, 1] = le.fit_transform (x[:, 1])

y = le.fit_transform ( y )

print (" Weather :", x[:, 0])
print (" Temp :", x[:, 1])
print (" Play :", y )

# Import Gaussian Naive Bayes model
from sklearn . naive_bayes import GaussianNB
# Create a Gaussian Classifier
model = GaussianNB ()
# Train the model using the training sets
model.fit (x, y)
# predict Output
predicted = model.predict ([[0 ,1]]) # 0: Overcast , 2: Mild
print (" Predicted Value :", predicted )
