import math
import random

def func1(x, y):
    return math.exp(-(x**2 + y**2))

def func2(x, y):
    return (1 - x) ** 2 + 100 * (y - x ** 2) ** 2

def hill_climbing_maximize(f):
    x = random.uniform(0, 1)
    y = random.uniform(0, 1)
    best_score = f(x, y)

    while True:
        found_better = False

        neighbors = [(x + dx, y + dy) for dx in [-0.1, 0, 0.1] for dy in [-0.1, 0, 0.1]]

        for neighbor in neighbors:
            nx, ny = neighbor
            if 0 <= nx <= 1 and 0 <= ny <= 1:
                score = f(nx, ny)
                if score > best_score:
                    best_score = score
                    x = nx
                    y = ny
                    found_better = True

        if not found_better:
            break

    return x, y, best_score

print("Function 1:")
x_opt, y_opt, score_opt = hill_climbing_maximize(func1)
print("Optimal point: (x = {}, y = {})".format(x_opt, y_opt))
print("Optimal score: {}".format(score_opt))

print("Function 2:")
x_opt, y_opt, score_opt = hill_climbing_maximize(func2)
print("Optimal point: (x = {}, y = {})".format(x_opt, y_opt))
print("Optimal score: {}".format(score_opt))

