#TASK NO 2

import numpy as np
import matplotlib.pyplot as plot
import pandas 
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn import metrics

dataset =pandas.read_csv('weather.csv')
print(dataset)

#   PREDICTION USING GROWING DAYS
x = dataset['Growing Days'].values.reshape(-1,1)
y = dataset['Temperature'].values.reshape(-1,1)

dataset.plot(x='Growing Days', y='Temperature', style='o')

plot.title('Growing Days VS Temperature')
plot.xlabel('Growing Days')
plot.ylabel('Temperature')
plot.show()

xTrain, xTest, yTrain, yTest = train_test_split(x, y, test_size = 0.2, random_state = 0)
LinearRegressor = LinearRegression()
LinearRegressor.fit(xTrain, yTrain)
yPrediction = LinearRegressor.predict(xTest)

df = pandas.DataFrame({'Actual': yTest.flatten(), 'Predicted': yPrediction.flatten()})
plot.scatter(xTrain, yTrain, color = 'yellow')
plot.plot(xTrain, LinearRegressor.predict(xTrain), color = 'purple')

plot.title('Growing Days VS Temperature (Training Set)')
plot.xlabel('Growing Days')
plot.ylabel('Temperature')
plot.show()
plot.scatter(xTest, yTest, color = 'yellow')
plot.plot(xTest, LinearRegressor.predict(xTest), color = 'purple')

plot.title('Growing Days VS Temperature (Testing Set)')
plot.xlabel('Growing Days')
plot.ylabel('Temperature')
plot.show()

print('Mean Absolute Error:',metrics.mean_absolute_error(yTest,yPrediction))
print('Mean Squared Error:',metrics.mean_squared_error(yTest,yPrediction))
print('Root Mean Squared Error:',np.sqrt(metrics.mean_squared_error(yTest,yPrediction)))



#   PREDICTION USING WIND SPEED
x = dataset['Wind Speed'].values.reshape(-1,1)
y = dataset['Temperature'].values.reshape(-1,1)

dataset.plot(x='Wind Speed', y='Temperature', style='o')

plot.title('Wind Speed VS Temperature')
plot.xlabel('Wind Speed')
plot.ylabel('Temperature')
plot.show()

xTrain, xTest, yTrain, yTest = train_test_split(x, y, test_size = 0.2, random_state = 0)
LinearRegressor = LinearRegression()
LinearRegressor.fit(xTrain, yTrain)
yPrediction = LinearRegressor.predict(xTest)

df = pandas.DataFrame({'Actual': yTest.flatten(), 'Predicted': yPrediction.flatten()})
plot.scatter(xTrain, yTrain, color = 'yellow')
plot.plot(xTrain, LinearRegressor.predict(xTrain), color = 'purple')

plot.title('Wind Speed VS Temperature (Training Set)')
plot.xlabel('Wind Speed')
plot.ylabel('Temperature')
plot.show()


plot.scatter(xTest, yTest, color = 'yellow')
plot.plot(xTest, LinearRegressor.predict(xTest), color = 'purple')

plot.title('Wind Speed VS Temperature (Testing Set)')
plot.xlabel('Wind Speed')
plot.ylabel('Temperature')
plot.show()

print('Mean Absolute Error:',metrics.mean_absolute_error(yTest,yPrediction))
print('Mean Squared Error:',metrics.mean_squared_error(yTest,yPrediction))
print('Root Mean Squared Error:',np.sqrt(metrics.mean_squared_error(yTest,yPrediction)))