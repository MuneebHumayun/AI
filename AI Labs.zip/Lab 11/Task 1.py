#TASK NO 1
import numpy as np
import matplotlib.pyplot as plot
import pandas
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn import metrics


dataset = pandas.read_excel(r"SalaryAge.xlsx")
x = dataset['YearsExperience'].values.reshape(-1,1)
y = dataset['Salary'].values.reshape(-1,1)
dataset.plot(x='YearsExperience', y='Salary', style='o')

plot.title('YearsExperience vs Salary')
plot.ylabel('Salary')
plot.show()

xTrain, xTest, yTrain, yTest = train_test_split(x, y, test_size = 0.2, random_state = 0)
LinearRegressor = LinearRegression()
LinearRegressor.fit(xTrain, yTrain)
yPrediction = LinearRegressor.predict(xTest)
df = pandas.DataFrame({'Actual': yTest.flatten(), 'Predicted': yPrediction.flatten()})

plot.scatter(xTrain, yTrain, color = 'red')
plot.plot(xTrain, LinearRegressor.predict(xTrain), color = 'blue')


plot.title('Salary vs Experience (Training set)')
plot.xlabel('Years of experience')
plot.ylabel('salary')
plot.show()


plot.scatter(xTest,yTest,color='red')
plot.plot(xTest, LinearRegressor.predict(xTest), color='blue')

plot.title('salary vs Experience (Testing set)')
plot.xlabel('year of experience')
plot.ylabel('Salary')
plot.show()

print('Mean Absolute Error:',metrics.mean_absolute_error(yTest,yPrediction))
print('Mean Squared Error:',metrics.mean_squared_error(yTest,yPrediction))
print('Root Mean Squared Error:',np.sqrt(metrics.mean_squared_error(yTest,yPrediction)))