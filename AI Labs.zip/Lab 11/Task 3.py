import numpy as np
import matplotlib.pyplot as plot
import pandas
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn import metrics


dataset = pandas.read_csv(r"StudentData.csv")
x = dataset['Year of Study'].values.reshape(-1,1)
y = dataset['Result'].values.reshape(-1,1)
dataset.plot(x='Year of Study', y='Result', style='o')

plot.title('Year of Study vs Result')
plot.ylabel('Result')
plot.show()

xTrain, xTest, yTrain, yTest = train_test_split(x, y, test_size = 0.2, random_state = 0)
LinearRegressor = LinearRegression()
LinearRegressor.fit(xTrain, yTrain)
yPrediction = LinearRegressor.predict(xTest)
df = pandas.DataFrame({'Actual': yTest.flatten(), 'Predicted': yPrediction.flatten()})

plot.scatter(xTrain, yTrain, color = 'red')
plot.plot(xTrain, LinearRegressor.predict(xTrain), color = 'blue')


plot.title('Year of Study vs Result (Training set)')
plot.xlabel('Year of Study')
plot.ylabel('Result')
plot.show()


plot.scatter(xTest,yTest,color='red')
plot.plot(xTest, LinearRegressor.predict(xTest), color='blue')

plot.title('Year of Study vs Result (Testing set)')
plot.xlabel('Year of Study')
plot.ylabel('Result')
plot.show()

print('Mean Absolute Error:',metrics.mean_absolute_error(yTest,yPrediction))
print('Mean Squared Error:',metrics.mean_squared_error(yTest,yPrediction))
print('Root Mean Squared Error:',np.sqrt(metrics.mean_squared_error(yTest,yPrediction)))