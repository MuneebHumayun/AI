
import math


class AStar:

    def __init__(self):
        self.adj_list = {
            'Ar':[('Ze',75),('Si',140),('Ti',118)],
            'Ze':[('Or',71),('Ar',75)],
            'Or':[('Ze',71),('Si',151)],
            'Si':[('Or',151),('Ar',140),('Fa',99),('Ri',80)],
            'Ri':[('Si',80),('Pi',97),('Cr',146)],
            'Cr':[('Ri',146),('Dr',120),('Pi',138)],
            'Pi':[('Ri',97),('Bu',101),('Cr',138)],
            'Fa':[('Si',99),('Bu',211)],
            'Ti':[('Ar',118),('Lu',111)],
            'Lu':[('Me',70),('Ti',111)],
            'Me':[('Dr',75),('Lu',70)],
            'Dr':[('Me',75),('Cr',120)],
            'Bu':[('Fa',211),('Pi',101)]
        }
                    
        self.hur_function = { 'Ar':266, 'Ze':374, 'Or':380, 'Si':253, 'Ri':193, 'Cr':160, 'Pi':100, 'Fa':176, 'Ti':329, 'Lu':244, 'Me':241, 'Dr':242, 'Bu':0 }

    def reconstruct_path(self, cameFrom, current):
        total_path = [current]
        while current in cameFrom.keys():
            current = cameFrom[current]
            total_path.insert(0, current)
        return total_path

    def A_Star(self, start, goal):
        openSet = set([start])
        cameFrom = {}
        
        gScore = dict.fromkeys(self.adj_list.keys(), math.inf)
        gScore[start] = 0
        fScore = dict.fromkeys(self.adj_list.keys(), math.inf)
        fScore[start] = 0

        while len(openSet) != 0:
            current = min(openSet, key=lambda x: fScore[x])

            if current == goal:
                return self.reconstruct_path(cameFrom, current)
        
            openSet.remove(current)

            for neighbor in self.adj_list[current]:
                temp_gScore = gScore[current] + neighbor[1]
                if temp_gScore < gScore[neighbor[0]]:
                    cameFrom[neighbor[0]] = current
                    gScore[neighbor[0]] = temp_gScore
                    fScore[neighbor[0]] = temp_gScore + self.hur_function[neighbor[0]]

                    if neighbor[0] not in openSet:
                        openSet.add(neighbor[0])
        
        return False


aStar = AStar()
print( aStar.A_Star('Ar', 'Bu') )
