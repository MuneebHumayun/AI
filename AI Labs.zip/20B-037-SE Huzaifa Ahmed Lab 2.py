import math

class Polynomial:
    def __init__(self, degree=None, coefficient=None):
        if degree is None:
            self._polyHead = None
        else:
            self._polyHead = _PolyTermNode(degree, coefficient)
            self._polyTail = self._polyHead

    def degree(self):
        if self._polyHead is None:
            return -1
        else:
            return self._polyHead.degree

    def __getitem__(self, degree):
        assert self.degree() >= 0, " Operation not permitted in empty polynomial ."
        curNode = self._polyHead
        while curNode is not None and curNode.degree >= degree:
            curNode = curNode.next
        if curNode is None or curNode.degree != degree:
            return 0.0
        else:
            return curNode.degree

    def __add__(self, rhsPoly):
        assert self.degree() >= 0 and rhsPoly.degree() >= 0, " Addition only allowed in non - empty Polynomials "
        newPoly = Polynomial()
        nodeA = self._polyHead
        nodeB = rhsPoly._polyHead
        while nodeA is not None and nodeB is not None:
            if nodeA.degree > nodeB.degree:
                degree = nodeA.degree
                value = nodeA.coefficient
                nodeA = nodeA.next
            elif nodeA.degree < nodeB.degree:
                degree = nodeB.degree
                value = nodeB.coefficient
                nodeB = nodeB.next

            else:
                degree = nodeA.degree
                value = nodeA.coefficient + nodeB.coefficient
                # adds when degree is same
                nodeA = nodeA.next
                nodeB = nodeB.next
            newPoly._appendTerm(degree, value)

        while nodeA is not None:
            newPoly._appendTerm(nodeA.degree, nodeA.coefficient)
            nodeA = nodeA.next
        # if the list itself is longer
        while nodeB is not None:
            newPoly._appendTerm(nodeB.degree, nodeB.coefficient)
            nodeB = nodeB.next
        return newPoly
    
    def evaluate(self, scalar):
        assert self.degree() >= 0, "Polynomial must not be empty."
        result = 0.0
        curNode = self._polyHead
        while curNode is not None :
            result += curNode.coefficient * (scalar ** curNode.degree)
            curNode = curNode.next
        return result


    def __sub__(self, rhsPoly):
        assert self.degree() >= 0 and rhsPoly.degree() >= 0, " Subtraction only allowed in non - empty Polynomials "
        newPoly = Polynomial()
        nodeA = self._polyHead
        nodeB = rhsPoly._polyHead
        while nodeA is not None and nodeB is not None:
            if nodeA.degree > nodeB.degree:
                degree = nodeA.degree
                value = nodeA.coefficient
                nodeA = nodeA.next
            elif nodeA.degree < nodeB.degree:
                degree = nodeB.degree
                value = -nodeB.coefficient
                nodeB = nodeB.next

            else:
                degree = nodeA.degree
                value = nodeA.coefficient - nodeB.coefficient
                # subtracts when degree is same
                nodeA = nodeA.next
                nodeB = nodeB.next
            newPoly._appendTerm(degree, value)

        while nodeA is not None:
            newPoly._appendTerm(nodeA.degree, nodeA.coefficient)
            nodeA = nodeA.next
        # if the list itself is longer
        while nodeB is not None:
            newPoly._appendTerm(nodeB.degree, -nodeB.coefficient)
            nodeB = nodeB.next
        return newPoly

    def __mul__(self, rhsPoly):
        assert self.degree() >= 0 and rhsPoly.degree() >= 0, "Multiplication only allowed on non-empty polynomials."
        node = self._polyHead
        newPoly = rhsPoly._termMultiply(node)
        
        node = node.next
        while node is not None :
            tempPoly = rhsPoly._termMultiply( node )
            newPoly = newPoly + tempPoly
            node = node.next
        return newPoly

    def _termMultiply(self, termNode):
        newPoly = Polynomial()
        curr = self._polyHead

        while curr is not None:
            newDegree = curr.degree + termNode.degree 
            newCoeff = curr.coefficient * termNode.coefficient

            newPoly._appendTerm(newDegree, newCoeff)
            curr = curr.next
        
        return newPoly
    
    # Helper method for appending terms in the polynomial
    def _appendTerm(self, degree, coefficient):
        if coefficient != 0.0:
            newTerm = _PolyTermNode(degree, coefficient)
            if self._polyHead is None:
                self._polyHead = newTerm
            else:
                self._polyTail.next = newTerm
            self._polyTail = newTerm


class _PolyTermNode(object):
    def __init__(self, degree, coefficient):
        self.degree = degree
        self.coefficient = coefficient
        self.next = None


def PolynomialTest():
    # POLYNOMIAL ADDITION

    poly1 = Polynomial(2, 5) + Polynomial(1, 3)
    # 5x^2 + 3x

    poly2 = Polynomial(3, 1) + Polynomial(0, 4)
    # x^3 + 4

    # POLYNOMIAL SUBTRACTION

    poly3 = poly2 - poly1
    # x^3 - 5x^2 - 3x + 4
    print("f(x) = x^3 - 5x^2 - 3x + 4")
    print("f(2) =", poly3.evaluate(2))
    
    # POLYNOMIAL MULTIPLICATION
    poly4 = poly2 * poly1

    print("\nf(x) = 5x^5 + 3x^4 + 20x^2 + 12x")
    print("f(2) =", poly4.evaluate(2))


class ComplexNumber:
    def __init__(self, real=0, comp=0):
        self.real = real
        self.comp = comp
    
    def theta(self):
        angle = math.atan(self.comp / self.real) * 180 / math.pi
        angle = round(angle, 2)
        if self.real > 0:
            return angle
        elif self.comp > 0:
            return (angle + 180) 
        else:
            return (angle - 180) 

    def Conjugate(self):
        return ComplexNumber(self.real, -self.comp)

    def __sub__(self, other):
        return ComplexNumber(self.real - other.real, self.comp - other.comp)
    
    def __pow__(self, n):
        result = self
        for _ in range(n):
            result = result._selfMul()
    def _selfMul(self):
        return ComplexNumber(self.real ** 2 - self.comp ** 2, 2 * self.comp)

z1 = ComplexNumber(-1, -2)
z2 = ComplexNumber(1, 1)

print(z2)
