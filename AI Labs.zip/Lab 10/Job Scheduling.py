import pandas as pd, scipy , numpy as np
from sklearn.preprocessing import MinMaxScaler
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import Normalizer
from sklearn.preprocessing import MinMaxScaler


ds = pd.read_excel("Job_Scheduling.xlsx")
x = ds.iloc[:, 0:4].values  # for input values
y = ds.iloc[:, 4].values  # for output value

imp = SimpleImputer(missing_values=np.nan, strategy="mean")
X = imp.fit_transform(x)
Y = y.reshape(-1, 1)
Y = imp.fit_transform(Y)
Y = Y.reshape(-1)

print(Y)


scaler = MinMaxScaler(feature_range=(0, 1))
scaled_X = scaler.fit_transform(X[:, 1].reshape(-1, 1))
np.set_printoptions(precision=3)
X[:, 1] = scaled_X.reshape(1, -1)
print(X[:, 1])


scaler = Normalizer().fit(X)
normalized_X = scaler.transform(X)
print(normalized_X)
