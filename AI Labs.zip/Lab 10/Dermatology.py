import pandas as pd, numpy as np
from sklearn.preprocessing import MinMaxScaler
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import Normalizer
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.metrics import confusion_matrix
from sklearn.neighbors import KNeighborsClassifier


ds = pd.read_csv("dermatology.data", header=None)
x = ds.iloc[:, :-1].values  # for input values
y = ds.iloc[:, 1].values  # for output value


imp = SimpleImputer(missing_values=np.nan, strategy="mean")
X = imp.fit_transform(x)
Y = y.reshape(-1, 1)
Y = Y.reshape(-1)
print(Y)


scaler = MinMaxScaler(feature_range=(0, 1))
scaled_X = scaler.fit_transform(X[:, 1].reshape(-1, 1))
np.set_printoptions(precision=3)
X[:, 1] = scaled_X.reshape(1, -1)
print(X[:, 1])


scaler = Normalizer().fit(X)
normalized_X = scaler.transform(X)
print(normalized_X)


X_train, X_test, y_train, y_test = train_test_split(normalized_X, Y, test_size=0.3, random_state=42)

knn = KNeighborsClassifier()

cv_scores = cross_val_score(knn, X_train, y_train, cv=10)

knn.fit(X_train, y_train)

y_pred = knn.predict(X_test)

conf_matrix = confusion_matrix(y_test, y_pred)
print("Confusion Matrix:")
print(conf_matrix)


print("Cross-Validation Accuracy: {:.4f}".format(cv_scores.mean()))

