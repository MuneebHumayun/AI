import pandas as pd, scipy , numpy as np
from sklearn.preprocessing import MinMaxScaler
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import Normalizer
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score

ds = pd.read_csv("Iris.csv")
x = ds.iloc[:, 0:4].values  # for input values
y = ds.iloc[:, 4].values  # for output value


imp = SimpleImputer(missing_values=np.nan, strategy="mean")
X = imp.fit_transform(x)
Y = y.reshape(-1, 1)
Y = Y.reshape(-1)
print(Y)


scaler = MinMaxScaler(feature_range=(0, 1))
scaled_X = scaler.fit_transform(X[:, 1].reshape(-1, 1))
np.set_printoptions(precision=3)
X[:, 1] = scaled_X.reshape(1, -1)
print(X[:, 1])


scaler = Normalizer().fit(X)
normalized_X = scaler.transform(X)
print(normalized_X)


X_train, X_test, y_train, y_test = train_test_split(normalized_X, Y, test_size=0.3)

neighbors = [1, 3, 5, 7, 9]

# Perform KNN classification for each number of neighbors
for n in neighbors:
    # Create KNN classifier with n neighbors
    knn = KNeighborsClassifier(n_neighbors=n)
    
    # Fit the classifier to the training data
    knn.fit(X_train, y_train)
    
    # Predict the classes for the testing data
    y_pred = knn.predict(X_test)
    
    # Calculate accuracy and print the result
    accuracy = accuracy_score(y_test, y_pred)
    print(f"Number of neighbors: {n}, Accuracy: {accuracy:.4f}")

