import pandas as pd, scipy, numpy as np
from sklearn.preprocessing import MinMaxScaler
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import Normalizer
from sklearn . model_selection import train_test_split

ds = pd.read_excel ("C:/Users/20B-019-SE/Pictures/Job_Scheduling.xlsx")
x = ds.iloc [: ,0:4]. values #for input values
y = ds.iloc [: ,4]. values #for output value


# Filling missing values
imp = SimpleImputer ( missing_values = np.nan , strategy ="mean")
X = imp.fit_transform ( x )
Y = y.reshape ( -1 ,1)
Y = imp.fit_transform ( Y )
Y = Y.reshape (-1)
print (Y)

scaler = MinMaxScaler ( feature_range = (0 ,1) )
rescaledX = scaler.fit_transform ( X[0 ,1].reshape( -1, 1) )
np.set_printoptions( precision = 3) # Setting precision for the output
X [: ,1] = rescaledX.reshape( 1, -1)
print ( X [: ,1])


scaler = Normalizer().fit( X )
normalizedX = scaler.transform( X )
print(normalizedX)

t_size = 0.30
X_train, X_test, Y_train, Y_test = train_test_split (X ,Y , test_size = t_size )
print(X_train.shape)

